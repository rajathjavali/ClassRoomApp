<?php
if($_POST['hello']){
echo "connected";
}
?>
